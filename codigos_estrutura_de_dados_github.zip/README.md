# Estrutura de Dados

Repositório com os códigos em linguagem C utilizados no portfólio da disciplina de Estrutura de Dados.

Aluno: Otavio Cezar Neves de Souza  
RA: 2707071  
Curso: Engenharia de Software

## Conteúdos

1. Variáveis, operadores e entrada/saída
2. Estruturas de decisão
3. Laços de repetição
4. Vetores e matrizes
5. Structs
6. Ponteiros
7. Listas encadeadas
8. Busca e remoção em listas
9. Listas circulares
10. Listas duplamente encadeadas
11. Pilhas
12. Filas

## Como executar

Compile qualquer arquivo `.c` com GCC:

```bash
gcc nome_do_arquivo.c -o programa
./programa
```
