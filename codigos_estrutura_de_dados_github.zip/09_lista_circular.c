#include <stdio.h>
#include <stdlib.h>

typedef struct No {
    int valor;
    struct No *prox;
} No;

No* inserirFinal(No *lista, int valor) {
    No *novo = (No*) malloc(sizeof(No));
    novo->valor = valor;

    if (lista == NULL) {
        novo->prox = novo;
        return novo;
    }

    No *p = lista;

    while (p->prox != lista) {
        p = p->prox;
    }

    p->prox = novo;
    novo->prox = lista;

    return lista;
}

void imprimirCircular(No *lista) {
    if (lista == NULL) {
        printf("Lista vazia.\n");
        return;
    }

    No *p = lista;

    do {
        printf("%d -> ", p->valor);
        p = p->prox;
    } while (p != lista);

    printf("(volta ao inicio)\n");
}

int main() {
    No *lista = NULL;

    lista = inserirFinal(lista, 10);
    lista = inserirFinal(lista, 20);
    lista = inserirFinal(lista, 30);

    imprimirCircular(lista);

    return 0;
}
