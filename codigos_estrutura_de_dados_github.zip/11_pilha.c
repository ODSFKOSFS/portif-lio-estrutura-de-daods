#include <stdio.h>
#include <stdlib.h>

typedef struct No {
    int valor;
    struct No *prox;
} No;

typedef struct {
    No *topo;
} Pilha;

void inicializar(Pilha *p) {
    p->topo = NULL;
}

void push(Pilha *p, int valor) {
    No *novo = (No*) malloc(sizeof(No));
    novo->valor = valor;
    novo->prox = p->topo;
    p->topo = novo;
}

int pop(Pilha *p) {
    if (p->topo == NULL) {
        printf("Pilha vazia.\n");
        return -1;
    }

    No *temp = p->topo;
    int valor = temp->valor;
    p->topo = temp->prox;
    free(temp);

    return valor;
}

int main() {
    Pilha pilha;

    inicializar(&pilha);

    push(&pilha, 10);
    push(&pilha, 20);
    push(&pilha, 30);

    printf("Removido: %d\n", pop(&pilha));
    printf("Removido: %d\n", pop(&pilha));

    return 0;
}
